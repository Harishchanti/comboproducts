package com.example.licious.in.comboproducts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComboproductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
