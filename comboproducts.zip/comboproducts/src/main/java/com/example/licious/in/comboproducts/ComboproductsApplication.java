package com.example.licious.in.comboproducts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComboproductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComboproductsApplication.class, args);
	}

}
